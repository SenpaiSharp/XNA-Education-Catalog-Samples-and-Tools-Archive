#region File Description
//-----------------------------------------------------------------------------
// SpriteSheetGame.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

#region Using Statements
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;
using SpriteSheetRuntime;
#endregion

namespace SpriteSheetSample
{
    /// <summary>
    /// Sample showing how to load and draw sprite sheets, which
    /// combine many separate sprites into a single larger texture.
    /// </summary>
    public class SpriteSheetGame : Microsoft.Xna.Framework.Game
    {
        #region Fields

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteSheet spriteSheet;
        SpriteFont spriteFont;
        Texture2D checker;

        #endregion

        #region Initialization


        public SpriteSheetGame()
        {
            Content.RootDirectory = "Content";

            graphics = new GraphicsDeviceManager(this);

            graphics.PreferredBackBufferWidth = 853;
            graphics.PreferredBackBufferHeight = 480;
        }


        /// <summary>
        /// Load your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteSheet = Content.Load<SpriteSheet>("SpriteSheet");
            spriteFont = Content.Load<SpriteFont>("Arial");
            checker = Content.Load<Texture2D>("Checker");
        }


        #endregion

        #region Update and Draw


        /// <summary>
        /// Allows the game to run logic.
        /// </summary>
        protected override void Update(GameTime gameTime)
        {
            HandleInput();

            base.Update(gameTime);
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        protected override void Draw(GameTime gameTime)
        {
            float time = (float)gameTime.TotalGameTime.TotalSeconds;

            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            // Draw a text label.
            spriteBatch.DrawString(spriteFont, "Here are some individual sprites,\n" +
                                               "all stored in a single sprite sheet:",
                                               new Vector2(100, 80), Color.White);

            // Draw a spinning cat sprite, looking it up from the sprite sheet by name.
            spriteBatch.Draw(spriteSheet.Texture, new Vector2(200, 250),
                             spriteSheet.SourceRectangle("cat"), Color.White,
                             time, new Vector2(50, 50), 1, SpriteEffects.None, 0);

            // Draw an animating glow effect, by rapidly cycling
            // through 7 slightly different sprite images.
            const int animationFramesPerSecond = 20;
            const int animationFrameCount = 7;

            // Look up the index of the first glow sprite.
            int glowIndex = spriteSheet.GetIndex("glow1");

            // Modify the index to select the current frame of the animation.
            glowIndex += (int)(time * animationFramesPerSecond) % animationFrameCount;

            // Draw the current glow sprite.
            spriteBatch.Draw(spriteSheet.Texture, new Rectangle(100, 150, 200, 200),
                             spriteSheet.SourceRectangle(glowIndex), Color.White);

            spriteBatch.End();

            DrawEntireSpriteSheetTexture();

            base.Draw(gameTime);
        }


        /// <summary>
        /// A real game would never do this, but when debugging, it is
        /// useful to draw the entire sprite sheet texture, so you can
        /// see how the individual sprite images have been arranged.
        /// </summary>
        void DrawEntireSpriteSheetTexture()
        {
            // Use SpriteSortMode.Immediate, so we can apply custom renderstates.
            spriteBatch.Begin(SpriteBlendMode.AlphaBlend,
                              SpriteSortMode.Immediate,
                              SaveStateMode.None);

            // Set the texture addressing mode to wrap, so we can repeat
            // many copies of our tiled checkerboard texture.
            GraphicsDevice.SamplerStates[0].AddressU = TextureAddressMode.Wrap;
            GraphicsDevice.SamplerStates[0].AddressV = TextureAddressMode.Wrap;

            // Draw a text label.
            spriteBatch.DrawString(spriteFont, "And here is the combined\n" +
                                               "sprite sheet texture:",
                                               new Vector2(450, 80), Color.White);

            int w = spriteSheet.Texture.Width;
            int h = spriteSheet.Texture.Height;

            Rectangle rect = new Rectangle(450, 150, w, h);

            // Draw a tiled checkerboard pattern in the background.
            spriteBatch.Draw(checker, rect, new Rectangle(0, 0, w, h), Color.White);

            // Draw the (alphablended) sprite sheet texture over the top.
            spriteBatch.Draw(spriteSheet.Texture, rect, Color.White);

            spriteBatch.End();
        }


        #endregion

        #region Handle Input


        /// <summary>
        /// Handles input for quitting the game.
        /// </summary>
        private void HandleInput()
        {
            KeyboardState currentKeyboardState = Keyboard.GetState();
            GamePadState currentGamePadState = GamePad.GetState(PlayerIndex.One);

            // Check for exit.
            if (currentKeyboardState.IsKeyDown(Keys.Escape) ||
                currentGamePadState.Buttons.Back == ButtonState.Pressed)
            {
                Exit();
            }
        }


        #endregion
    }


    #region Entry Point

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    static class Program
    {
        static void Main()
        {
            using (SpriteSheetGame game = new SpriteSheetGame())
            {
                game.Run();
            }
        }
    }

    #endregion
}
